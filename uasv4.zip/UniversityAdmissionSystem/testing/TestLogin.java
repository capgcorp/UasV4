import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import org.apache.log4j.PropertyConfigurator;
import org.junit.Before;
import org.junit.Test;

import com.cg.uas.dao.DaoUasImpl;
import com.cg.uas.dao.IDaoUas;
import com.cg.uas.dto.Application;
import com.cg.uas.exception.UasException;


public class TestLogin {
	IDaoUas dao = null;
	
	@Before
	public void setUp() throws Exception {
		PropertyConfigurator.configure("resources/log4j.properties");
		dao = new DaoUasImpl();
	}
	
	//-----------------------MAC LOGIN -------------------------//
	@Test
	public void testNullValuesMacLogin() {

		try {
			boolean expected = false;
			String userName,password;
			userName = "";
			password = "";
			boolean actual = dao.macLogin(userName, password);
			assertTrue(expected == actual);
		} catch (UasException e) {
			fail("did not expect exception");
		}
	}
	
	@Test
	public void testValidMacLogin() {

		try {
			boolean expected = true;
			String userName,password;
			userName = "mac";
			password = "mac";
			boolean actual = dao.macLogin(userName, password);
			assertTrue(expected == actual);
		} catch (UasException e) {
			fail("did not expect exception");
		}
	}
	
	@Test
	public void testCaseSensitivityMacLogin() {

		try {
			boolean expected = false;
			String userName,password;
			userName = "Mac";
			password = "mac";
			boolean actual = dao.macLogin(userName, password);
			assertTrue(expected == actual);
		} catch (UasException e) {
			fail("did not expect exception");
		}
	}
	
	//-------------------------------ADMIN LOGIN--------------------------------------//
	@Test
	public void testNullValuesAdminLogin() {

		try {
			boolean expected = false;
			String userName,password;
			userName = "";
			password = "";
			boolean actual = dao.adminLogin(userName, password);
			assertTrue(expected == actual);
		} catch (UasException e) {
			fail("did not expect exception");
		}
	}
	
	@Test
	public void testValidAdminLogin() {

		try {
			boolean expected = true;
			String userName,password;
			userName = "admin";
			password = "admin";
			boolean actual = dao.adminLogin(userName, password);
			assertTrue(expected == actual);
		} catch (UasException e) {
			fail("did not expect exception");
		}
	}
	
	@Test
	public void testCaseSensitivityAdminLogin() {

		try {
			boolean expected = false;
			String userName,password;
			userName = "Admin";
			password = "admin";
			boolean actual = dao.adminLogin(userName, password);
			assertTrue(expected == actual);
		} catch (UasException e) {
			fail("did not expect exception");
		}
	}
	
	//-------------------------------View list of application----------------------------//
	
	@Test
	public void testApplicationList() {

		try {
			String programName;
			programName="";
			List<Application> actualList = dao.allApplications(programName);
			assertTrue(actualList==null);
		} catch (UasException e) {
			fail("did not expect exception");
		}
	}
	
	
	@Test
	public void testInvalidEntryApplicationList() {
		try {
			String programName;
			programName="invalid_programName";
			List<Application> actualList = dao.allApplications(programName);
			assertTrue(actualList==null);
		} catch (UasException e) {
			fail("did not expect exception");
		}
	}
	
	
	
}
